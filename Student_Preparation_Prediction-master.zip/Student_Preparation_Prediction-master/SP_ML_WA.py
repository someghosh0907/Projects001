#Description : Predicts the student preparation

#importing libs
import pandas as pd
import numpy as np
import sklearn
from sklearn import linear_model
from sklearn.utils import shuffle
from sklearn.metrics import accuracy_score
import pickle
from PIL import Image
import streamlit as st

#create title & sub-title
st.write("""
# Student Preparation Prediction
Predicts the preparation percentage of a student before a certain exam !
""")

#display image
image = Image.open('C:/Users/SAYAN/PycharmProjects/StudentPreparation_ML_WD/UEMLogo.png')
st.image(image, caption='Machine Learning Project CSE 3rd year', use_column_width=True)


#get data
data = pd.read_csv("C:/Users/SAYAN/PycharmProjects/StudentPreparation_ML_WD/student-mat.csv", sep=";")
data = data[["G1", "G2", "G3", "studytime", "failures", "absences"]]

#set a subheader
st.subheader('Data Information : ')
#show the data as a table
st.dataframe(data)
#show stats on the data
st.write(data.describe())
#show data as a chart
chart = st.bar_chart(data)

predict = "G3"

#spliting data into X and Y
X = np.array(data.drop([predict], 1))
y = np.array(data[predict])

#spliting the data set into 75% training and 25% testing
x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size = 0.1)

#get input rom the user
def get_user_input():
    G1 = st.sidebar.slider('First Term Grades', 0, 20, 10)
    G2 = st.sidebar.slider('Second Term Grades', 0, 20, 10)
    studytime = st.sidebar.slider('Study Time', 0, 10, 5)
    failures = st.sidebar.slider('Failures', 0, 3, 1)
    absences = st.sidebar.slider('Absences', 0, 20, 10)

    #store a dic into a var
    user_data = {'First Term Grades': G1,
                 'Second Term Grades': G2,
                 'Study Time': studytime,
                 'Failures': failures,
                 'Absences': absences
                }

    #tranform the data into a data frame
    features = pd.DataFrame(user_data, index = [0])
    return features

#store the user input into a var
user_input = get_user_input()

#set a subheader and display the user input
st.subheader('User Input: ')
st.write(user_input)

#create and train model
pickle_in = open("C:/Users/SAYAN/PycharmProjects/StudentPreparation_ML_WD/studentmodel.pickle", "rb")
linear = pickle.load(pickle_in)

#show the models metrics
#st.subheader('Model Test Accurracy Score:')
#st.write(str(accuracy_score(y_test, linear.predict(x_test))*100)+'%')

#store the model prediction in a var
predictions = linear.predict(user_input)

#set a subheader and display the result
st.subheader('Student Preparation Percent : ')
st.write(str(int((predictions/20)*100))+'%')
st.subheader('How much he/she can get in the upcoming exam : ')
st.write(str(int(predictions))+'/20')